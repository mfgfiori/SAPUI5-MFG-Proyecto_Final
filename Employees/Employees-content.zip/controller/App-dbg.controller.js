// @ts-nocheck
sap.ui.define([
    "sap/ui/core/mvc/Controller",
],
    /**
         * @param {typeof sap.ui.core.mvc.Controller} Controller     
         */
    function (Controller) {
        return Controller.extend("projectfinal.Employees.controller.App", {            
            onInit: function () {
            }
        });
});